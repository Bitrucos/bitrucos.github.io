#!/bin/bash
# uso: bash gen.sh desde hasta   (dentro de voz/)
cd /home/user/bitrucos/video19/voz
for i in $(seq $1 $2); do
  l=$(sed -n "${i}p" lines.txt)
  for k in 1 2 3; do
    env -u PYTHONPATH HOME=/home/user PYTHONUTF8=1 LANG=C.UTF-8 ~/ttsenv/bin/edge-tts --voice es-MX-JorgeNeural --rate "+6%" --text "$l" --write-media L$i.mp3 2>/dev/null && break; sleep 2
  done
  ffmpeg -loglevel error -y -i L$i.mp3 -af "silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.02,areverse,silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.03,areverse" -ar 48000 -ac 1 L$i.wav
  echo "$i $(ffprobe -v error -show_entries format=duration -of csv=p=0 L$i.wav)"
done
